package com.barsha.journey_journal.Room;

import androidx.annotation.CheckResult;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface JournalDaO {
    @Query("SELECT * FROM Journal_Table")
    List<JournalEntity> getAllJournals();


    @Query("Select * from Journal_Table")
    LiveData<List<JournalEntity>> getJournalLiveData();


    @Insert
    void insertAll(JournalEntity... journalEntities);

    @Insert
    long insertJournal(JournalEntity journalEntity);

    @Query("Update Journal_Table set title=:title,records=:records,date=:date,image=:image where journalId=:Id")
    void updateJournal(int Id, String title, String records, String date, byte[] image);

    @Update
    void update(JournalEntity journalEntity);

    @Delete
    void deleteJournal(JournalEntity journalEntity);

    @Query("Delete From Journal_Table where journalId =:Id")
    void deletebyId (int Id);

}


package com.barsha.journey_journal.Room;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;

import androidx.room.TypeConverter;

import java.io.ByteArrayOutputStream;

public class BitmapConvert {

        @TypeConverter
        public static byte [] getbyteArrayFromBitmap(Bitmap bitmapPic){
            ByteArrayOutputStream byteArrayBitmapStream = new ByteArrayOutputStream();
            bitmapPic.compress(Bitmap.CompressFormat.JPEG, 0, byteArrayBitmapStream);
            byte [] b = byteArrayBitmapStream.toByteArray();
            return b;
        }

        @TypeConverter
        public static Bitmap getBitMapFromByteArray(byte [] arr){
            return BitmapFactory.decodeByteArray(arr, 0, arr.length);

        }

        @TypeConverter
        public static String BitMapToString(Bitmap bitmap){
            ByteArrayOutputStream baos = new  ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG,0, baos);
            byte [] b=baos.toByteArray();
            String temp= Base64.encodeToString(b, Base64.DEFAULT);
            if(temp==null)
            {
                return null;
            }
            else
                return temp;
        }

        @TypeConverter
        public static Bitmap StringToBitMap(String encodedString){
            try {
                byte[] encodeByte = Base64.decode(encodedString,Base64.DEFAULT);
                Bitmap bitmap= BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.length);
                if(bitmap==null)
                {
                    return null;
                }
                else
                {
                    return bitmap;
                }

            } catch(Exception e) {
                e.getMessage();
                return null;
            }
        }
    }


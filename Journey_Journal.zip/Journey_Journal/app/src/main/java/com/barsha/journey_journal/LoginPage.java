package com.barsha.journey_journal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.barsha.journey_journal.Room.MyJournalDatabase;
import com.barsha.journey_journal.Room.UserEntity;
import com.barsha.journey_journal.Room.UserRegistrationRepository;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.checkbox.MaterialCheckBox;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textview.MaterialTextView;

public class LoginPage extends AppCompatActivity {
    private MaterialButton LoginButton;
    private EditText EmailText;
    private EditText PasswordText;
    private MaterialTextView NormalTextView;
    private UserRegistrationRepository repository;
    private FloatingActionButton Google;
    private GoogleSignInOptions gso;
    private GoogleSignInClient mGoogleSignInClient;
    private final int RC_SIGN_IN = 100;
    private MyJournalDatabase myJournalDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);
        // initiated all the Material buttons, editTextViews, MaterialTextView:
        repository = new UserRegistrationRepository(this);
        LoginButton = findViewById(R.id.LoginButton);
        EmailText = findViewById(R.id.EmailText);
        PasswordText = findViewById(R.id.PasswordText);
        NormalTextView = findViewById(R.id.NormalTextView);
        Google = findViewById(R.id.Google);

// Configuring a sign-in to request the user's ID, email address, and basic
// profile. ID and basic profile will be included in DEFAULT_SIGN_IN.
        gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        // Building a GoogleSignInClient with the options specified by
        // gso(object of GoogleSignInOptions).
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

//registering Material button's OnClickListener to sign in the user when clicked:
        Google.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Tapping handle sign-in button by creating a sign-in intent
                //with the getSignInIntent method, and starting the intent
                // with startActivityForResult.
                switch (view.getId()) {
                    case R.id.Google:
                        signIn();

                        //Intent event to navigate from this page to ShowDataList/Dashboard page  of application:
                        Intent intent = new Intent(LoginPage.this, ShowDataList.class);
                        startActivity(intent);
                        break;
                }
            }

            private void signIn() {
                Intent signInIntent = mGoogleSignInClient.getSignInIntent();
                startActivityForResult(signInIntent, RC_SIGN_IN);
                Toast.makeText(LoginPage.this, "GoogleUserId login",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // performed click event on Material login button
        LoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String EmailAddress = EmailText.getText().toString();
                String Password = PasswordText.getText().toString();
                // check empty
                // Sending checkUser(EmailAddress,Password) by using repository object:
                UserEntity userEntity = repository.loginUser(EmailAddress, Password);
                if (userEntity != null) {
                    //Intent event to navigate from this page to ShowDataList/Dashboard page  of application:
                    Intent intent = new Intent(LoginPage.this,
                            ShowDataList.class);
                    Toast.makeText(LoginPage.this, "Opening Dashboard",
                            Toast.LENGTH_SHORT).show();
                    startActivity(intent);
                } else {
                    Toast.makeText(LoginPage.this,
                            "User not registered yet", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // performed click event on Material NormalTextView.
            NormalTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Intent event to navigate from this page to Registration page  of application:
                Intent intent = new Intent(LoginPage.this,
                        RegistrationPage.class);
                Toast.makeText(LoginPage.this,
                        "Opening Registration Page", Toast.LENGTH_SHORT).show();
                startActivity(intent);
            }
        });

        //After coming from 'Register or login option Page' by selecting 'Login' Button:
        String reached = getIntent().getStringExtra("reached");
        Toast.makeText(LoginPage.this, reached, Toast.LENGTH_SHORT).show();
    }

        @java.lang.Override
        protected void onResume() {
            super.onResume();
            // Checking for existing Google Sign In account, if the user is
            // already signed in, the GoogleSignInAccount will be non-null.
            GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
            updateUI(account);
        }

        @Override
        public void onActivityResult(int requestCode, int resultCode, Intent data) {
            super.onActivityResult(requestCode, resultCode, data);

            // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
            if (requestCode == RC_SIGN_IN) {
                // The Task returned from this call is always completed, no need to attach
                // a listener.
                Task<GoogleSignInAccount> task =
                        GoogleSignIn.getSignedInAccountFromIntent(data);
                handleSignInResult(task);
            }
        }

        private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
            try {
                GoogleSignInAccount account = completedTask.getResult(ApiException.class);

                // Signed in successfully, show authenticated UI.

                Toast.makeText(getApplicationContext(),
                        "Signed In", Toast.LENGTH_LONG).show();
                     updateUI(account);

                //Intent event to navigate from this page to ShowDataList/Dashboard page  of application:
                Intent intent = new Intent(getApplication(), ShowDataList.class);
                startActivity(intent);

            } catch (ApiException e) {
                // The ApiException status code indicates the detailed failure reason.
                // Please refer to the GoogleSignInStatusCodes class reference for
                // more information.
                //Log.w(TAG, "signInResult:failed code=" + e.getStatusCode());
                updateUI(null);
            }
        }

        private void updateUI(GoogleSignInAccount account) {
        }
    }


package com.barsha.journey_journal;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.barsha.journey_journal.Room.BitmapConvert;
import com.barsha.journey_journal.Room.JournalDaO;
import com.barsha.journey_journal.Room.JournalEntity;
import com.barsha.journey_journal.Room.MyJournalDatabase;
import com.github.drjacky.imagepicker.ImagePicker;
import com.google.android.material.button.MaterialButton;

import java.io.IOException;
import java.util.Calendar;
import java.util.Date;

public class UpdateActivity extends AppCompatActivity {
    private MaterialButton LogoutButton1;
    private EditText TitleEditText1;
    private EditText RecordThoughtsEditText1;
    private MaterialButton UpdateButton;
    private ImageView UserProfileImage1;
    private MaterialButton GalleryImageButton1;
    private MaterialButton AddPhotoButton1;
    private EditText Date1;
    Bitmap bitmap = null;
    int Id;
    private DatePickerDialog datePickerDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        LogoutButton1 = findViewById(R.id.LogoutButton1);

        // performed click event on Material LogoutButton1:
        LogoutButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(UpdateActivity.this,
                        LoginPage.class);
                startActivity(intent);
                Toast.makeText(UpdateActivity.this,
                        "Logging out", Toast.LENGTH_SHORT).show();
            }
        });

// initiated all the Material Buttons, Edit TextViews and Image View.
        TitleEditText1 = findViewById(R.id.TitleEditText1);
        RecordThoughtsEditText1 = findViewById(R.id.RecordThoughtsEditText1);
        UpdateButton = findViewById(R.id.UpdateButton);
        UserProfileImage1 = findViewById(R.id.UserProfileImage1);
        GalleryImageButton1 = findViewById(R.id.GalleryImageButton1);
        AddPhotoButton1 = findViewById(R.id.AddPhotoButton1);
        Date1 = findViewById(R.id.Date1);


        Id = Integer.parseInt(getIntent().getStringExtra("Id"));
        TitleEditText1.setText(getIntent().getStringExtra("Title"));
        Date1.setText(getIntent().getStringExtra("Date"));
        RecordThoughtsEditText1.setText(getIntent().getStringExtra("Records"));

        // performed click event on edit text
        Date1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // calender class's instance and get current date , month and year from calender
                final Calendar c = Calendar.getInstance();
                int mYear = c.get(Calendar.YEAR); // current year
                int mMonth = c.get(Calendar.MONTH); // current month
                int mDay = c.get(Calendar.DAY_OF_MONTH); // current day

                // date picker dialog
                datePickerDialog = new DatePickerDialog(UpdateActivity.this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                // set day of month , month and year value in the edit text
                                Date1.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.show();
            }
        });


// performed click event on Material update button
        UpdateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Title = TitleEditText1.getText().toString();
                String Thoughts = RecordThoughtsEditText1.getText().toString();
                String date = Date1.getText().toString();
                MyJournalDatabase myJournalDatabase = MyJournalDatabase
                        .getInstance(getApplicationContext());
                JournalDaO journalDaO = myJournalDatabase.journalDaO();
                journalDaO.updateJournal(Id, TitleEditText1.getText().toString(),
                        RecordThoughtsEditText1.getText().toString(), Date1.getText().toString(), BitmapConvert.getbyteArrayFromBitmap(bitmap));
                Toast.makeText(UpdateActivity.this,
                        "Updated Successfully", Toast.LENGTH_SHORT).show();

                // Intent event to navigate from this page to ShowDataList i.e Dashboard Page of application:
                Intent intent = new Intent(UpdateActivity.this,
                        ShowDataList.class);
                startActivity(intent);
            }
        });

        // performed click event on  Material button GalleryImageButton1 which is a upload button to upload photo
        // for updating/editing in the journal:
        GalleryImageButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImagePicker.Companion.with(UpdateActivity.this)
                        .crop()                    //Crop image(Optional),
                                                // Check Customization for more option
                        .compress(1024)            //Final image size will be less
                                                     // than 1 MB(Optional)
                        .maxResultSize(1080, 1080)    //Final image
                                    // resolution will be less than 1080 x
                                     // 1080(Optional)
                        .start();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // performed click event on Material Button AddPhotoButton1 which is a add button to upload the selected
        // photo for updating after selecting it:
        AddPhotoButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    Uri uri = data.getData();
                    UserProfileImage1.setImageURI(uri);
                    bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(),
                            uri);
                    UserProfileImage1.setImageBitmap(bitmap);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }
}







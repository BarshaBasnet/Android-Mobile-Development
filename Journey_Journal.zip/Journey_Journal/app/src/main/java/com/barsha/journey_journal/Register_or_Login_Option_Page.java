package com.barsha.journey_journal;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class Register_or_Login_Option_Page extends AppCompatActivity {
private MaterialButton Button_Register, LoginButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_or_login_option_page);

        // initiated the Material Register and Login Button.
        Button_Register = findViewById(R.id.Button_Register);
        LoginButton = findViewById(R.id.LoginButton);

        // performed click event on Material Register button
        Button_Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Register_or_Login_Option_Page.this,"Register",
                        Toast.LENGTH_SHORT).show();

                //Intent event to navigate from this page to Registration Page of application:
                Intent intent = new Intent(Register_or_Login_Option_Page.this,
                        RegistrationPage.class);
                intent.putExtra("reached",
                        "Reached Registration Page of Application");
                startActivity(intent);
            }
        });

        // performed click event on Material login button
        LoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(Register_or_Login_Option_Page.this,"Login",
                        Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(Register_or_Login_Option_Page.this,
                        LoginPage.class);
                intent.putExtra("reached", "Reached Login Page of Application");
                startActivity(intent);
            }
        });

        //When coming from Welcome Page to this page:
        String reached = getIntent().getStringExtra("reached");
        Toast.makeText(Register_or_Login_Option_Page.this, reached,
                Toast.LENGTH_SHORT).show();
    }
}


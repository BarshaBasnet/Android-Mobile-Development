package com.barsha.journey_journal;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.DatePickerDialog;
import android.content.Intent;

import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.Toast;

import com.barsha.journey_journal.Room.JournalDaO;
import com.barsha.journey_journal.Room.JournalEntity;
import com.barsha.journey_journal.Room.MyJournalDatabase;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.material.button.MaterialButton;

import java.util.Calendar;
import java.util.List;

public class ShowDataList extends AppCompatActivity{

    private RecyclerView Recycler_View;
    private GoogleSignInOptions gso;
    private GoogleSignInClient mGoogleSignInClient;
    MaterialButton Logout_Button, Create_Button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_data_list);

        Recycler_View = findViewById(R.id.Recycler_View);
        LinearLayoutManager manager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        Recycler_View.setLayoutManager(manager);


        MyJournalDatabase myjournalDatabase = MyJournalDatabase.getInstance(getApplicationContext());
        JournalDaO journalDaO = myjournalDatabase.journalDaO();

        List<JournalEntity> journalEntityList = journalDaO.getAllJournals();
        DataRecyclerAdapter dataRecyclerAdapter = new DataRecyclerAdapter(journalEntityList);
        Recycler_View.setAdapter(dataRecyclerAdapter);

       // initiated the Logout and Create Material Buttons.
        Logout_Button = findViewById(R.id.Logout_Button);
        Create_Button = findViewById(R.id.Create_Button);


        // perform click event on Material create button
        Create_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent createJournal = new Intent(getApplicationContext(), AddJournalPage.class);
                startActivity(createJournal);
                Toast.makeText(ShowDataList.this, "Add New Journal", Toast.LENGTH_SHORT).show();
            }
        });

        // perform click event on Material logout button
        Logout_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                        .requestEmail()
                        .build();
                mGoogleSignInClient = GoogleSignIn.getClient(getApplication(), gso);
                mGoogleSignInClient.signOut();

//Intent event to navigate from this page to LoginPage of application:
                Intent intent = new Intent(getApplicationContext(), LoginPage.class);
                startActivity(intent);

                //Toast message while logging out:
                Toast.makeText(ShowDataList.this, "Logging out", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
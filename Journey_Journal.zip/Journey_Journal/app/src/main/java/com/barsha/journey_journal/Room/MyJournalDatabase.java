package com.barsha.journey_journal.Room;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities =  {UserEntity.class, JournalEntity.class} , version = 2 , exportSchema = false)
public abstract class MyJournalDatabase extends RoomDatabase {
    private  static  final String JournalDB = "Journal_DB";

    // below line is to create instance for our database class.
    private  static  MyJournalDatabase instance;

    private static MyJournalDatabase myJournalDatabase = null;

        // Creating/ Defining  object for the interface UserDAO that we have created:
    // Or this code of line has been used to create abstract variable for dao.
        public abstract UserDaO userDaO();
    public abstract JournalDaO journalDaO();

     // the code present below has been used for getting instance for my database:
        public static synchronized MyJournalDatabase getInstance(Context context) {

            // below line of code is used to check if the instance is null or not:
            if (instance == null) {

                // if the instance is null we have to create a new instance and for that
                // we have to create a database builder and pas our database class with our database name
                //as below:
                instance = Room.databaseBuilder(context.getApplicationContext(), MyJournalDatabase.class, JournalDB)
                        .allowMainThreadQueries(). //this line of code disables the main thread query check for Room.
                        fallbackToDestructiveMigration() // this code of line allows us to add fall back to destructive migration
                                                            // to our database or
                        // in other word, it allows Room to destructively recreate database tables if in case migrations that would
                        // migrate old database schemas to the latest schema version are not found.

                        .build();  // This line of code has been used to simply build our database and initialize it.
            }
            // after creating an instance, to return our instance, we have to use line of code as below:
            return instance;
        }
    }



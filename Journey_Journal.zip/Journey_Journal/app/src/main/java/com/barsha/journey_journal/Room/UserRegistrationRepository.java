package com.barsha.journey_journal.Room;

import android.content.Context;

import androidx.lifecycle.LiveData;

import java.util.List;

public class UserRegistrationRepository {

    private final MyJournalDatabase db;
    private final UserDaO userDaO;

    public UserRegistrationRepository(Context context) {
        this.db = MyJournalDatabase.getInstance(context);
        this.userDaO = db.userDaO();
    }


    public LiveData<List<UserEntity>> fetchLiveUsers() {
        return userDaO.getUserLiveData();
    }

    //public List<UserEntity> loadAllByIds(int UserId){
      //  return userDaO.loadAllByIds(UserId);
    //}

    public long insertUser(UserEntity userEntity){

       return userDaO.insertUser(userEntity);
    }

    //public UserEntity insertUser(String email, String pass) {

      //  return userDaO.insertUser(email, pass);
    //}

    public UserEntity loginUser(String email, String pass){

        return userDaO.loginUser(email,pass);
    }


    }








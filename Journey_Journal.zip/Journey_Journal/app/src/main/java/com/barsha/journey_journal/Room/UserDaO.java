package com.barsha.journey_journal.Room;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface UserDaO {


    @Query("SELECT * FROM UserRegistration")
    List<UserEntity> getAllUsers();


    @Query("Select * from UserRegistration")
    LiveData<List<UserEntity>>getUserLiveData();

    @Query("select * from UserRegistration where email=:email and pass =:pass")
    UserEntity loginUser(String email,String pass);

    @Insert
    void insertAll(UserEntity... userEntities);

    @Insert
    long insertUser(UserEntity userEntity);

    //@Query("select * from UserRegistration where email=:email,pass=:pass,fullName=:fullName,gender=:gender,phone=:phone")
    //UserEntity insertUser(String email, String pass, String fullName,String gender,String phone);

    @Delete
    void delete(UserEntity userEntity);

//    @Update("Update UserRegistration set title=:title, date=:date,records=:records,image=:image where journalId=:Id")
//    void updateUser(UserEntity userEntity);

    @Delete
    void deleteUser(UserEntity userEntity);

//    @Query
//    void updateJournal(int Id, String title, String date, String records, byte[] image);

    @Update
    void update(JournalEntity journalEntity);

    //UserEntity insertUser(UserEntity userEntity);
   // @Query("select * from UserRegistration where email=:email")
    //UserEntity checkUser(String email);
}





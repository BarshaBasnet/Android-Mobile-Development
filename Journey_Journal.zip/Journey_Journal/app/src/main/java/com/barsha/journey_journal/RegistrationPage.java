package com.barsha.journey_journal;


import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.room.Room;


import android.content.Intent;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.barsha.journey_journal.Room.UserDaO;
import com.barsha.journey_journal.Room.MyJournalDatabase;
import com.barsha.journey_journal.Room.UserEntity;
import com.barsha.journey_journal.Room.UserRegistrationRepository;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.radiobutton.MaterialRadioButton;

import java.util.List;

//import com.barsha.journey_journal.Room.UserRegistration;

public class RegistrationPage extends AppCompatActivity {
    private EditText FullName_Text, Email_Text, Phone_Text, Password_Text, ConfirmPassword_Text;
    private MaterialButton Register;
    private UserRegistrationRepository userRegistrationRepository;
    UserDaO userDaO;
    private MaterialRadioButton MGender_Button,FGender_Button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_page);
        userRegistrationRepository = new UserRegistrationRepository(this);

        // initiated all the Material EditText boxes and buttons.
        FullName_Text = findViewById(R.id.FullName_Text);
        MGender_Button= findViewById(R.id.MGender_Button);
        FGender_Button = findViewById(R.id.FGender_Button);
        Email_Text = findViewById(R.id.Email_Text);
        Phone_Text = findViewById(R.id.Phone_Text);
        Password_Text = findViewById(R.id.Password_Text);
        ConfirmPassword_Text = findViewById(R.id.ConfirmPassword_Text);
        Register = findViewById(R.id.Register);
        userDaO = MyJournalDatabase.getInstance(this).userDaO();


        // performed click event on Material Register button
        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String FullName = FullName_Text.getText().toString();
                String Gender = MGender_Button.getText().toString();
                FGender_Button.getText().toString();
                String EmailAddress = Email_Text.getText().toString();
                String PhoneNumber = Phone_Text.getText().toString();
                String Password = Password_Text.getText().toString();
                String ConfirmPassword = ConfirmPassword_Text.getText().toString();


                // if any of the TextBoxes are empty, show message 'User Data not inserted fully':
                if (FullName_Text.getText().toString().isEmpty() ||
                        Email_Text.getText().toString().isEmpty() ||
                        Phone_Text.getText().toString().isEmpty() || Password_Text.getText().
                        toString().isEmpty() || ConfirmPassword_Text.getText().toString().
                        isEmpty()) {
                    Toast.makeText(RegistrationPage.this,
                            " User Data not inserted fully ", Toast.LENGTH_SHORT).show();

                }

                 //If password doesnot match, shows message 'Password not matched'
                else if(!Password.equals(ConfirmPassword)){
                    Toast.makeText(RegistrationPage.this,
                            "Password not matched", Toast.LENGTH_SHORT).show();
                }

                else {

                     userRegistrationRepository.insertUser(
                            new UserEntity(0, FullName,Gender,EmailAddress,PhoneNumber,Password)
                    );

                    //Intent event to navigate from this page to  AccountCreationAlertPage of application:
                    Intent intent = new Intent(RegistrationPage.this,
                            AccountCreationAlertPage.class);
                    Toast.makeText(RegistrationPage.this,
                            "Opening AccountCreationAlertPage", Toast.LENGTH_SHORT).show();
                    startActivity(intent);
                    Toast.makeText(RegistrationPage.this,
                            "Data inserted successfully", Toast.LENGTH_SHORT).show();
                }
            }
        });

//Applied onCheckedChangeListener in radio button:
 MGender_Button.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
     @Override
     public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
         //if-else condition, where if male selected, shows 'male selected' else shows message 'Female selected'.
         if (compoundButton.getId() == R.id.MGender_Button)
         Toast.makeText(RegistrationPage.this, "Male selected", Toast.LENGTH_SHORT).show();
         else{
             if (compoundButton.getId() == R.id.FGender_Button)
                 Toast.makeText(RegistrationPage.this, "Female selected", Toast.LENGTH_SHORT).show();
         }

     }
 });

//Applied onCheckedChangeListener in radio button:
 FGender_Button.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
     @Override
     public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
         //if-else condition, where if Female selected, shows 'Female selected' else shows message 'Male selected'.
         if (compoundButton.getId() == R.id.FGender_Button)
         Toast.makeText(RegistrationPage.this, "Female selected", Toast.LENGTH_SHORT).show();

         else{
             if (compoundButton.getId() == R.id.MGender_Button)
                 Toast.makeText(RegistrationPage.this, "Male selected", Toast.LENGTH_SHORT).show();
         }

     }
 });
}



    @Override
    protected void onStart() {
        super.onStart();
        userRegistrationRepository = new UserRegistrationRepository(this);
        fetchUsers();
    }

    private void fetchUsers() {
        userRegistrationRepository.fetchLiveUsers().observe(this, new Observer<List<UserEntity>>() {
            @Override
            public void onChanged(List<UserEntity> userEntities) {
                //at last, we will be able to get user list here.
            }
        });

    }

    private void insertUser(UserEntity userEntity) {
        userRegistrationRepository.insertUser(userEntity);
    }


}


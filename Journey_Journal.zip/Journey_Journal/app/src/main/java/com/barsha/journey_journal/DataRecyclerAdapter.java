package com.barsha.journey_journal;

import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.barsha.journey_journal.Room.BitmapConvert;
import com.barsha.journey_journal.Room.JournalDaO;
import com.barsha.journey_journal.Room.JournalEntity;
import com.barsha.journey_journal.Room.MyJournalDatabase;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.MaterialAutoCompleteTextView;
import com.google.android.material.textview.MaterialTextView;

import java.util.List;


public class DataRecyclerAdapter extends RecyclerView.Adapter<DataRecyclerAdapter.DataItemHolder> {

    List<JournalEntity> journal_entity;

    public DataRecyclerAdapter(List<JournalEntity> journal_entity) {
        this.journal_entity = journal_entity;
    }

    //Calling onCreateViewHolder(ViewGroup, parent, int viewtype) to get a  needs a new RecyclerView.ViewHolder
    // of the given type for RecyclerView to represent an item.
    //OR
    // creating a new RecyclerView.ViewHolder and
    // to initialize some private fields to be used by RecyclerView.
    @NonNull
    @Override
    public DataRecyclerAdapter.DataItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.user_item_layout, parent, false);

        return (new DataItemHolder(view));
    }


    // calling onBindViewHolder(ViewHolder, int position) to display the data at the specified position.
    // and to update the contents of the RecyclerView.ViewHolder.itemView to reflect the item at
    // the given position.
    @Override
    public void onBindViewHolder(@NonNull DataRecyclerAdapter.DataItemHolder holder, int position) {

        JournalEntity Entity = journal_entity.get(position);
        String title = Entity.getTitle();
        String date = Entity.getDate();
        String Records = Entity.getRecords();
        byte[] image = Entity.getImage();
        String id = String.valueOf(Entity.getJournalId());

        holder.ID.setText(id);
        holder.TitleText.setText(title);
        holder.DescriptionText.setText(Records);
        holder.DateText.setText(date);
        holder.IMAGE.setImageBitmap(BitmapConvert.getBitMapFromByteArray(image));



       //performed click event on edit button by defining holder
        // to ask the adapter about an item's position whenever we click on it (ViewHolder item), so
        // that we will get the latest position of this item in terms of Adapter’s logic.
        holder.EditButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(new Intent(holder.EditButton.getContext(), UpdateActivity.class));
                intent.putExtra("Id", String.valueOf(journal_entity.get(holder.getAdapterPosition()).getJournalId()));
                intent.putExtra("Title", journal_entity.get(holder.getAdapterPosition()).getTitle());
                intent.putExtra("Records", journal_entity.get(holder.getAdapterPosition()).getRecords());
                intent.putExtra("Date", journal_entity.get(holder.getAdapterPosition()).getDate());
                intent.putExtra("IMAGE", journal_entity.get(holder.getAdapterPosition()).getImage());
                holder.EditButton.getContext().startActivity(intent);
            }
        });


// performed click event on holder.delete button same as for Material edit button:
        holder.DeleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyJournalDatabase myJournalDatabase = MyJournalDatabase.getInstance(holder.ID.getContext());
                JournalDaO  journalDaO = myJournalDatabase.journalDaO();

                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());

                builder.setMessage("Do you want to remove data?")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                                journalDaO.deletebyId(journal_entity.get(holder.getAdapterPosition()).getJournalId());

                                journal_entity.remove(holder.getAdapterPosition());

                                Toast.makeText(view.getContext(), " Data has been deleted successfully.", Toast.LENGTH_SHORT).show();

                                notifyDataSetChanged();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();
                            }
                        });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();

            }
        });

        // performed click event on holder.share button same as for Material delete and Material edit button:
        holder.ShareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                String link = "http://play.google.com";
                intent.putExtra(Intent.EXTRA_TEXT, link);
                view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        view.getContext().startActivity(Intent.createChooser(intent, "Share by"));
                    }
                });
            }
        });

    }

   // to return the total number of items in the data set held by the adapter.
    @Override
    public int getItemCount() {
        return journal_entity.size();
    }

    public static class DataItemHolder extends RecyclerView.ViewHolder{
        private final ImageView IMAGE;
        private final MaterialTextView ID,DateText,TitleText, DescriptionText;
        private final MaterialButton DeleteButton, EditButton, ShareButton;


        public DataItemHolder(View view){
            super(view);

            // initiated all the Material Buttons, Material textViews and imageView.
            IMAGE = view.findViewById(R.id.IMAGE);
            ID = view.findViewById(R.id.ID);
            DateText = view.findViewById(R.id.DateText);
            TitleText = view.findViewById(R.id.TitleText);
            DescriptionText = view.findViewById(R.id.DescriptionText);
            DeleteButton = view.findViewById(R.id.DeleteButton);
            EditButton = view.findViewById(R.id.EditButton);
            ShareButton = view.findViewById(R.id.ShareButton);

        }

    }

}
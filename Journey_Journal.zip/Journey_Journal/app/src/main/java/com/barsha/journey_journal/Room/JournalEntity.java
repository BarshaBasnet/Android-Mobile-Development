package com.barsha.journey_journal.Room;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "Journal_Table")
public class JournalEntity {
    @PrimaryKey(autoGenerate = true)
    private int journalId;
    private String title;
    private String records;
    private String date;
    private byte[] image;

    public JournalEntity(int journalId, String title,String records, String date, byte[] image) {
        this.journalId = journalId;
        this.title = title;
        this.records = records;
        this.date = date;
        this.image = image;
    }

    public int getJournalId() {
        return journalId;
    }

    public void setJournalId(int journalId) {
        this.journalId = journalId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getRecords() {
        return records;
    }

    public void setRecords(String records) {
        this.records = records;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }
}

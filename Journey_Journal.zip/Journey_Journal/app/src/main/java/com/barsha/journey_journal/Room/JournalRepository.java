package com.barsha.journey_journal.Room;

import android.content.Context;

import androidx.lifecycle.LiveData;

import java.util.List;

public class JournalRepository {
    private final MyJournalDatabase db;
    private final JournalDaO journalDaO;

    public JournalRepository(Context context) {
        this.db = MyJournalDatabase.getInstance(context);
        this.journalDaO = db.journalDaO();
    }

    public LiveData<List<JournalEntity>> fetchLiveJournals() {
        return journalDaO.getJournalLiveData();
    }

    //public List<UserEntity> loadAllByIds(int UserId){
    //  return userDaO.loadAllByIds(UserId);
    //}

    public long insertJournal(JournalEntity journalEntity){
        return journalDaO.insertJournal( journalEntity);
    }

    public void updateJournal(JournalEntity journalEntity){
        journalDaO.update(journalEntity);
    }

    public void deleteJournal(JournalEntity journalEntity){
        journalDaO.deleteJournal(journalEntity);
    }

}

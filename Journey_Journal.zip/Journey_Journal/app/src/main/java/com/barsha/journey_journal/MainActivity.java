package com.barsha.journey_journal;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class MainActivity extends AppCompatActivity {
    private MaterialButton StartButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // initiated the Material Start Button.
        StartButton = findViewById(R.id.StartButton);


        // performed click event on Material start button
        StartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "Lets get started",
                        Toast.LENGTH_SHORT).show();

                //Intent event to navigate from this page to Register_or_Login_Option_Page of application:
                Intent intent = new Intent(MainActivity.this,
                        Register_or_Login_Option_Page.class);
                intent.putExtra("reached",
                        "Reached Register or Login Option Screen of Application");
                startActivity(intent);
            }
        });
    }

    // performed checkAndRequestPermissions event for capturing image using camera and gallery.
    void checkAndRequestPermissions() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE}, 100);
        } else {
            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(cameraIntent, 101);
        }
    }
}





















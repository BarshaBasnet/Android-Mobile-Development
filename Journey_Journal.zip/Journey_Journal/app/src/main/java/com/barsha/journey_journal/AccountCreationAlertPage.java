package com.barsha.journey_journal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class AccountCreationAlertPage extends AppCompatActivity {
   private MaterialButton ContinueButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_creation_alert_page);

        // initiated the Material Continue Button.
        ContinueButton = findViewById(R.id.ContinueButton);

        // perform click event on Material Continue button
        ContinueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(AccountCreationAlertPage.this,
                        "Continue To Homepage/Dashboard Page",
                        Toast.LENGTH_SHORT).show();
                //Intent event to navigate from this page to AccountCreationAlertPage of application:
                Intent intent = new Intent(AccountCreationAlertPage.this,
                        ShowDataList.class);

                // Shows this specific message while navigating to Dashboard page of application:
                intent.putExtra("Coming",
                        "Coming from AccountCreationAlertPage of Application");
                startActivity(intent);
            }
        });
    }
}
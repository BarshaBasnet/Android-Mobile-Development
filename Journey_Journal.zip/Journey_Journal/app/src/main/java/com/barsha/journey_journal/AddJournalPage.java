package com.barsha.journey_journal;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.barsha.journey_journal.Room.BitmapConvert;
import com.barsha.journey_journal.Room.JournalDaO;
import com.barsha.journey_journal.Room.JournalEntity;
import com.barsha.journey_journal.Room.MyJournalDatabase;
import com.github.drjacky.imagepicker.ImagePicker;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.radiobutton.MaterialRadioButton;
import com.google.android.material.textview.MaterialTextView;

import java.io.IOException;
import java.util.Calendar;

public class AddJournalPage extends AppCompatActivity {
    private MaterialButton LogoutButton, AddPhotoButton, SaveButton, GalleryImageButton;
    private EditText TitleEditText, RecordThoughtsEditText, Date;
    private ImageView UserProfileImage;
    private DatePickerDialog datePickerDialog;
    Bitmap bitmap = null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_journal_page);
        // initiated the Material Logout Button.
        LogoutButton = findViewById(R.id.LogoutButton);

        // initiated the EditText box.
        Date = findViewById(R.id.Date);

        // performed click event on edit text
        Date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // calender class's instance and get current date , month and year from calender
                final Calendar c = Calendar.getInstance();
                int mYear = c.get(Calendar.YEAR); // current year
                int mMonth = c.get(Calendar.MONTH); // current month
                int mDay = c.get(Calendar.DAY_OF_MONTH); // current day

                // date picker dialog
                datePickerDialog = new DatePickerDialog(AddJournalPage.this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                // set day of month , month and year value in the edit text
                                Date.setText(dayOfMonth + "/" + (monthOfYear + 1) + "/" + year);
                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.show();
            }
        });

        // performed click event on Material Logout button:
        LogoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AddJournalPage.this, LoginPage.class);
                startActivity(intent);
                Toast.makeText(AddJournalPage.this, "Logging out", Toast.LENGTH_SHORT).show();
            }
        });

        // initiated all the EditText boxes and buttons of the page.
        TitleEditText = findViewById(R.id.TitleEditText);
        RecordThoughtsEditText = findViewById(R.id.RecordThoughtsEditText);
        AddPhotoButton = findViewById(R.id.AddPhotoButton);
        SaveButton = findViewById(R.id.SaveButton);
        UserProfileImage = findViewById(R.id.UserProfileImage);
        GalleryImageButton = findViewById(R.id.GalleryImageButton);


        // performed click event on Material Save button:
        SaveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Title = TitleEditText.getText().toString();
                String Thoughts = RecordThoughtsEditText.getText().toString();
                String date = Date.getText().toString();
                MyJournalDatabase myJournalDatabase = MyJournalDatabase.getInstance(getApplicationContext());
                JournalDaO journalDaO = myJournalDatabase.journalDaO();
                journalDaO.insertJournal(new JournalEntity(0, Title, Thoughts, date, BitmapConvert.getbyteArrayFromBitmap(bitmap)));
                Toast.makeText(AddJournalPage.this, "Saved Successfully", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(AddJournalPage.this, ShowDataList.class);
                startActivity(intent);
                //Toast.makeText(AddJournalPage.this, Thoughts, Toast.LENGTH_SHORT).show();
            }
        });

        // performed click event on Material GalleryImageButton which is a upload button to upload photo to the journal:
        GalleryImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImagePicker.Companion.with(AddJournalPage.this)
                        .crop()                    //Crop image(Optional), Check Customization for more option
                        .compress(1024)            //Final image size will be less than 1 MB(Optional)
                        .maxResultSize(1080, 1080)    //Final image resolution will be less than 1080 x 1080(Optional)
                        .start();


            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // performed click event on AddPhotoButton which is a add button to upload the selected
        // photo to the journal after selecting it:
        AddPhotoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try {
                    Uri uri = data.getData();
                    UserProfileImage.setImageURI(uri);
                    bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
                    UserProfileImage.setImageBitmap(bitmap);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }
}













package com.barsha.journey_journal.Room;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "UserRegistration")
public class UserEntity {
    @PrimaryKey(autoGenerate = true)
    private int userId;

    private String fullName;

    private String gender;

    private String email;

    private String phone;

    private String pass;


    public UserEntity(int userId, String fullName, String gender, String email, String phone, String pass) {
        this.userId = userId;
        this.fullName = fullName;
        this.gender =  gender;
        this.email = email;
        this.phone = phone;
        this.pass = pass;


    }

    public int getUserId() {
        return userId;
    }

    public String getFullName() {
        return fullName;
    }

    public String getGender() {
        return gender;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getPass() {
        return pass;
    }


    public void setUserId(int userId) {
        this.userId = userId;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

}
















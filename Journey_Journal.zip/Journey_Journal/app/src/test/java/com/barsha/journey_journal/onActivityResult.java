package com.barsha.journey_journal;

public interface onActivityResult {
}
